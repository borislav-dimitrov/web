function myFunction() {
  document.getElementById("someParagraph").innerHTML = "Changed!";
}
