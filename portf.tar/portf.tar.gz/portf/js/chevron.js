function chevronMover() {
    let chevron = document.getElementById('chevron');
    // let moverChevron = document.getElementById('mover_chevron'); fas fa-chevron-down fas fa-angle-double-down
    let wrapper = document.getElementById('wrapper-arrow');

    wrapper.addEventListener('mouseenter', function() {
        fadeOutIn(chevron, 'enter');
    }, false);

    wrapper.addEventListener('mouseleave', function() {
        fadeOutIn(chevron, 'leave');
    }, false);
}

function fadeOutIn(element, state) {
    var op = 1; // initial opacity
    var timer = setInterval(function() {
        if (op <= 0.1) {
            clearInterval(timer);
            if (state === 'enter') {
                element.classList.remove('fa-chevron-down');
                element.classList.add('fa-angle-double-down');
            }
            if (state === 'leave') {
                chevron.classList.remove('fa-angle-double-down');
                chevron.classList.add('fa-chevron-down');
            }
            fadeIn(element);
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op -= op * 0.1;
    }, 10);
}

function fadeIn(element) {
    var op = 0.1; // initial opacity
    element.style.display = 'block';
    var timer = setInterval(function() {
        if (op >= 1) {
            clearInterval(timer);
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 10);
}