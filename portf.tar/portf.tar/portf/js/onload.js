$(document).ready(function() {
    // functions goes here
    chevronMover();
});